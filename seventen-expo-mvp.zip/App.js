import React, { useMemo, useState } from 'react';
import {
  SafeAreaView,
  ScrollView,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Image,
  Alert,
} from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { Ionicons } from '@expo/vector-icons';

const storyImage = require('./assets/seven-ten-story.jpeg');
const whyJoinImage = require('./assets/seven-ten-why-join.jpeg');

const businessRoles = [
  { id: 'dj', title: 'DJ', icon: 'headset-outline', desc: 'פרופיל, סגנונות, זמינות ומחיר.' },
  { id: 'club', title: 'בעל מועדון', icon: 'business-outline', desc: 'איתור ספקים, DJs ומחליפים דחופים.' },
  { id: 'producer', title: 'מפיק אירועים', icon: 'sparkles-outline', desc: 'בניית אירוע מלא, תקציב והצעות מחיר.' },
  { id: 'photographer', title: 'צלם', icon: 'camera-outline', desc: 'תיק עבודות, זמינות ופניות.' },
  { id: 'staff', title: 'צוות אירועים', icon: 'people-outline', desc: 'ברמנים, מלצרים, דיילות ומארחות.' },
  { id: 'supplier', title: 'ספק נוסף', icon: 'construct-outline', desc: 'אטרקציות, סאונד, תאורה ועוד.' },
];

const services = [
  'DJ',
  'צלם סטילס',
  'וידאו',
  'מפיק אירועים',
  'מגנטים',
  'ברמנים',
  'דיילות / מארחות',
  'אטרקציות',
  'סאונד ותאורה',
  'עיצוב אירוע',
];

export default function App() {
  const [screen, setScreen] = useState('home');
  const [role, setRole] = useState('');
  const [saved, setSaved] = useState([]);
  const [eventBudget, setEventBudget] = useState('');
  const [selectedServices, setSelectedServices] = useState(['DJ', 'צלם סטילס']);

  const estimatedTotal = useMemo(() => {
    const base = {
      DJ: 4500,
      'צלם סטילס': 3500,
      וידאו: 3000,
      'מפיק אירועים': 6000,
      מגנטים: 1200,
      ברמנים: 2200,
      'דיילות / מארחות': 1800,
      אטרקציות: 2500,
      'סאונד ותאורה': 3000,
      'עיצוב אירוע': 4000,
    };
    return selectedServices.reduce((sum, item) => sum + (base[item] || 0), 0);
  }, [selectedServices]);

  const save = (type) => {
    setSaved([{ type, role, date: new Date().toLocaleString('he-IL') }, ...saved]);
    Alert.alert('נשמר בהצלחה', 'הנתונים נשמרו בגרסת ההדגמה.');
  };

  const toggleService = (service) => {
    setSelectedServices((prev) =>
      prev.includes(service) ? prev.filter((item) => item !== service) : [...prev, service]
    );
  };

  const Header = () => (
    <View style={styles.header}>
      <TouchableOpacity onPress={() => setScreen('home')} style={styles.logoBox}>
        <Text style={styles.logoSmall}>710</Text>
      </TouchableOpacity>
      <View>
        <Text style={styles.headerTitle}>SEVEN TEN</Text>
        <Text style={styles.headerSub}>Events • Music • Services</Text>
      </View>
    </View>
  );

  const BackButton = ({ to = 'home' }) => (
    <TouchableOpacity style={styles.backButton} onPress={() => setScreen(to)}>
      <Ionicons name="arrow-forward" color="#F6C343" size={20} />
      <Text style={styles.backText}>חזרה</Text>
    </TouchableOpacity>
  );

  return (
    <SafeAreaView style={styles.app}>
      <StatusBar style="light" />
      <ScrollView contentContainerStyle={styles.container}>
        <Header />

        {screen === 'home' && (
          <>
            <View style={styles.hero}>
              <View style={styles.logoCircle}>
                <Text style={styles.logo}>SEVEN{'\n'}TEN</Text>
              </View>
              <Text style={styles.heroTitle}>מחברים בין אנשים, מוזיקה ואירועים.</Text>
              <Text style={styles.heroText}>
                פלטפורמה אחת ללקוחות פרטיים, בעלי עסקים, DJs, מפיקים, מועדונים, צלמים וספקים.
              </Text>

              <TouchableOpacity style={styles.goldButton} onPress={() => setScreen('accountType')}>
                <Text style={styles.goldButtonText}>צור חשבון</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.darkButton} onPress={() => setScreen('login')}>
                <Text style={styles.buttonText}>התחבר</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.linkButton} onPress={() => setScreen('guest')}>
                <Text style={styles.linkText}>המשך כאורח</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.card}>
              <Text style={styles.sectionTitle}>מה יש בגרסה הזו?</Text>
              <Feature text="הרשמה כלקוח פרטי או כבעל עסק" />
              <Feature text="בחירת תחום עסקי: DJ, מועדון, מפיק, צלם ועוד" />
              <Feature text="בונה אירוע עם שירותים ומחיר משוער" />
              <Feature text="עמוד הסיפור של Seven Ten ועמוד למה להצטרף" />
            </View>
          </>
        )}

        {screen === 'accountType' && (
          <View style={styles.card}>
            <BackButton />
            <Text style={styles.badge}>צור חשבון</Text>
            <Text style={styles.title}>מי אתה?</Text>
            <TouchableOpacity
              style={styles.choiceCard}
              onPress={() => {
                setRole('לקוח פרטי');
                setScreen('privateForm');
              }}
            >
              <Ionicons name="person-outline" color="#F6C343" size={34} />
              <View style={styles.choiceText}>
                <Text style={styles.choiceTitle}>אני לקוח פרטי</Text>
                <Text style={styles.text}>חתונה, יום הולדת, אירוע חברה או אירוע פרטי.</Text>
              </View>
            </TouchableOpacity>

            <TouchableOpacity style={styles.choiceCard} onPress={() => setScreen('businessType')}>
              <Ionicons name="briefcase-outline" color="#F6C343" size={34} />
              <View style={styles.choiceText}>
                <Text style={styles.choiceTitle}>אני בעל עסק / ספק שירות</Text>
                <Text style={styles.text}>DJ, מפיק, בעל מועדון, צלם, צוות אירועים או ספק.</Text>
              </View>
            </TouchableOpacity>
          </View>
        )}

        {screen === 'businessType' && (
          <View style={styles.card}>
            <BackButton to="accountType" />
            <Text style={styles.badge}>בעל עסק / ספק שירות</Text>
            <Text style={styles.title}>בחר את התחום שלך</Text>
            {businessRoles.map((item) => (
              <TouchableOpacity
                key={item.id}
                style={styles.roleRow}
                onPress={() => {
                  setRole(item.title);
                  setScreen('providerForm');
                }}
              >
                <Ionicons name={item.icon} color="#F6C343" size={26} />
                <View style={styles.choiceText}>
                  <Text style={styles.roleTitle}>{item.title}</Text>
                  <Text style={styles.text}>{item.desc}</Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        )}

        {screen === 'privateForm' && (
          <View style={styles.card}>
            <BackButton to="accountType" />
            <Text style={styles.badge}>לקוח פרטי</Text>
            <Text style={styles.title}>ספר לנו על האירוע</Text>
            <Input placeholder="שם מלא" />
            <Input placeholder="טלפון" keyboardType="phone-pad" />
            <Input placeholder="סוג אירוע: חתונה / יום הולדת / חברה" />
            <Input placeholder="תאריך האירוע" />
            <Input placeholder="עיר / אזור" />
            <Input placeholder="מה אתה מחפש? DJ, צלם, מפיק, צוות..." multiline />
            <TouchableOpacity style={styles.goldButton} onPress={() => save('פניית לקוח')}>
              <Text style={styles.goldButtonText}>שמור פנייה</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.darkButton} onPress={() => setScreen('eventBuilder')}>
              <Text style={styles.buttonText}>פתח בונה אירוע</Text>
            </TouchableOpacity>
          </View>
        )}

        {screen === 'providerForm' && (
          <View style={styles.card}>
            <BackButton to="businessType" />
            <Text style={styles.badge}>{role}</Text>
            <Text style={styles.title}>פתיחת פרופיל עסקי</Text>
            <Input placeholder="שם מלא / שם העסק" />
            <Input placeholder="טלפון" keyboardType="phone-pad" />
            <Input placeholder="עיר / אזור פעילות" />
            <Input placeholder="סגנון / קטגוריה / התמחות" />
            <Input placeholder="מחיר / טווח מחירים" />
            <Input placeholder="ניסיון, שירותים, זמינות וקישורים" multiline />
            <TouchableOpacity style={styles.goldButton} onPress={() => save('פרופיל עסקי')}>
              <Text style={styles.goldButtonText}>שמור פרופיל</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.darkButton} onPress={() => setScreen('whyJoin')}>
              <Text style={styles.buttonText}>למה להצטרף אלינו?</Text>
            </TouchableOpacity>
          </View>
        )}

        {screen === 'eventBuilder' && (
          <View style={styles.card}>
            <BackButton to="privateForm" />
            <Text style={styles.badge}>Event Builder</Text>
            <Text style={styles.title}>בונה אירוע</Text>
            <Input placeholder="שם האירוע" />
            <Input placeholder="מספר מוזמנים" keyboardType="numeric" />
            <Input placeholder="מיקום האירוע" />
            <Input placeholder="תקציב" keyboardType="numeric" value={eventBudget} onChangeText={setEventBudget} />

            <Text style={styles.sectionTitle}>בחר שירותים</Text>
            <View style={styles.chipsWrap}>
              {services.map((service) => (
                <TouchableOpacity
                  key={service}
                  style={[styles.chip, selectedServices.includes(service) && styles.chipActive]}
                  onPress={() => toggleService(service)}
                >
                  <Text style={[styles.chipText, selectedServices.includes(service) && styles.chipTextActive]}>
                    {service}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>

            <View style={styles.estimateBox}>
              <Text style={styles.estimateLabel}>מחיר משוער</Text>
              <Text style={styles.estimateValue}>₪{estimatedTotal.toLocaleString('he-IL')}</Text>
              <Text style={styles.text}>בהמשך המערכת תשווה ספקים אמיתיים ותייצר הצעת מחיר ללקוח.</Text>
            </View>
          </View>
        )}

        {screen === 'story' && (
          <View style={styles.card}>
            <BackButton />
            <Text style={styles.badge}>המותג</Text>
            <Text style={styles.title}>הסיפור של Seven Ten</Text>
            <Image source={storyImage} style={styles.brandImage} resizeMode="cover" />
            <Text style={styles.text}>
              Seven Ten נולדה מתוך עולם הלילה, המוזיקה והאירועים. המטרה היא להפוך את הכישרון,
              הניסיון והחיבורים למערכת אחת שמחברת בין לקוחות, ספקים, מועדונים ומפיקים.
            </Text>
          </View>
        )}

        {screen === 'whyJoin' && (
          <View style={styles.card}>
            <BackButton to={role ? 'providerForm' : 'home'} />
            <Text style={styles.badge}>לספקים ובעלי עסקים</Text>
            <Text style={styles.title}>למה להצטרף ל־Seven Ten?</Text>
            <Image source={whyJoinImage} style={styles.brandImage} resizeMode="cover" />
            <Feature text="חשיפה ללקוחות רלוונטיים ולאנשים שמחפשים שירות עכשיו" />
            <Feature text="פרופיל מקצועי שמרכז תיק עבודות, מחירים וזמינות" />
            <Feature text="ניהול פניות והזמנות במקום אחד" />
            <Feature text="בעתיד: צ׳אט, חוזים, תשלומים, דירוגים ולוח שנה" />
          </View>
        )}

        {screen === 'login' && (
          <View style={styles.card}>
            <BackButton />
            <Text style={styles.title}>התחברות</Text>
            <Input placeholder="טלפון / מייל" />
            <Input placeholder="סיסמה" secureTextEntry />
            <TouchableOpacity style={styles.goldButton} onPress={() => Alert.alert('בקרוב', 'נחבר מערכת משתמשים אמיתית.')}>
              <Text style={styles.goldButtonText}>התחבר</Text>
            </TouchableOpacity>
          </View>
        )}

        {screen === 'guest' && (
          <View style={styles.card}>
            <BackButton />
            <Text style={styles.title}>כניסה כאורח</Text>
            <Text style={styles.text}>כאן נציג חיפוש בסיסי, קטגוריות וספקים מומלצים לפני הרשמה.</Text>
            <TouchableOpacity style={styles.goldButton} onPress={() => setScreen('eventBuilder')}>
              <Text style={styles.goldButtonText}>נסה לבנות אירוע</Text>
            </TouchableOpacity>
          </View>
        )}

        <View style={styles.navGrid}>
          <NavItem icon="home-outline" label="בית" onPress={() => setScreen('home')} />
          <NavItem icon="sparkles-outline" label="בונה אירוע" onPress={() => setScreen('eventBuilder')} />
          <NavItem icon="book-outline" label="הסיפור" onPress={() => setScreen('story')} />
          <NavItem icon="ribbon-outline" label="להצטרף" onPress={() => setScreen('whyJoin')} />
        </View>

        <View style={styles.card}>
          <Text style={styles.sectionTitle}>שמירות בהדגמה</Text>
          {saved.length === 0 ? (
            <Text style={styles.text}>עדיין אין פרופילים או פניות.</Text>
          ) : (
            saved.map((item, index) => (
              <View key={`${item.date}-${index}`} style={styles.savedItem}>
                <Text style={styles.savedTitle}>{item.type}</Text>
                <Text style={styles.text}>{item.role || 'כללי'} · {item.date}</Text>
              </View>
            ))
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

function Input(props) {
  return (
    <TextInput
      {...props}
      placeholderTextColor="#8F9BB3"
      style={[styles.input, props.multiline && styles.textarea]}
      textAlign="right"
    />
  );
}

function Feature({ text }) {
  return (
    <View style={styles.featureRow}>
      <Ionicons name="checkmark-circle" color="#F6C343" size={20} />
      <Text style={styles.featureText}>{text}</Text>
    </View>
  );
}

function NavItem({ icon, label, onPress }) {
  return (
    <TouchableOpacity style={styles.navItem} onPress={onPress}>
      <Ionicons name={icon} color="#F6C343" size={22} />
      <Text style={styles.navText}>{label}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  app: { flex: 1, backgroundColor: '#070B13' },
  container: { padding: 18, paddingBottom: 44 },
  header: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    gap: 12,
    marginBottom: 16,
  },
  logoBox: {
    width: 48,
    height: 48,
    borderRadius: 18,
    backgroundColor: '#F6C343',
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoSmall: { color: '#0A1020', fontWeight: '900', fontSize: 18 },
  headerTitle: { color: '#FFF', fontSize: 22, fontWeight: '900', letterSpacing: 2, textAlign: 'right' },
  headerSub: { color: '#A8B3C7', textAlign: 'right', marginTop: 2 },
  hero: {
    backgroundColor: '#111B2D',
    borderRadius: 30,
    padding: 24,
    borderWidth: 1,
    borderColor: '#26364F',
    marginBottom: 14,
  },
  logoCircle: {
    width: 170,
    height: 170,
    borderRadius: 85,
    alignSelf: 'center',
    borderWidth: 1,
    borderColor: '#F6C343',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 18,
    backgroundColor: '#0D1424',
  },
  logo: { color: '#F6C343', fontSize: 29, textAlign: 'center', fontWeight: '900', letterSpacing: 4 },
  heroTitle: { color: '#FFF', fontSize: 27, fontWeight: '900', textAlign: 'center', marginBottom: 10 },
  heroText: { color: '#B8C2D6', fontSize: 16, lineHeight: 25, textAlign: 'center', marginBottom: 12 },
  card: {
    backgroundColor: '#111B2D',
    borderRadius: 24,
    padding: 18,
    borderWidth: 1,
    borderColor: '#26364F',
    marginBottom: 14,
  },
  title: { color: '#FFF', fontSize: 26, fontWeight: '900', textAlign: 'right', marginBottom: 12 },
  sectionTitle: { color: '#FFF', fontSize: 20, fontWeight: '900', textAlign: 'right', marginBottom: 12 },
  text: { color: '#B8C2D6', fontSize: 15.5, lineHeight: 24, textAlign: 'right' },
  badge: {
    color: '#F6C343',
    alignSelf: 'flex-end',
    borderColor: 'rgba(246,195,67,.45)',
    borderWidth: 1,
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 999,
    marginBottom: 10,
    overflow: 'hidden',
  },
  goldButton: { backgroundColor: '#F6C343', borderRadius: 16, padding: 16, marginTop: 10 },
  goldButtonText: { color: '#111827', fontSize: 17, fontWeight: '900', textAlign: 'center' },
  darkButton: {
    backgroundColor: '#172238',
    borderRadius: 16,
    padding: 16,
    marginTop: 10,
    borderWidth: 1,
    borderColor: '#31425F',
  },
  buttonText: { color: '#FFF', fontSize: 16, fontWeight: '800', textAlign: 'center' },
  linkButton: { padding: 14, marginTop: 4 },
  linkText: { color: '#F6C343', textAlign: 'center', fontWeight: '800' },
  backButton: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    alignSelf: 'flex-end',
    gap: 6,
    marginBottom: 8,
  },
  backText: { color: '#F6C343', fontWeight: '800' },
  choiceCard: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    backgroundColor: '#0D1424',
    borderRadius: 18,
    padding: 16,
    borderWidth: 1,
    borderColor: '#31425F',
    marginTop: 12,
    gap: 12,
  },
  choiceText: { flex: 1 },
  choiceTitle: { color: '#FFF', fontSize: 19, fontWeight: '900', textAlign: 'right', marginBottom: 4 },
  roleRow: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    backgroundColor: '#0D1424',
    borderRadius: 16,
    padding: 14,
    borderWidth: 1,
    borderColor: '#31425F',
    marginTop: 10,
    gap: 12,
  },
  roleTitle: { color: '#FFF', fontSize: 17, fontWeight: '900', textAlign: 'right' },
  input: {
    backgroundColor: '#070D18',
    borderWidth: 1,
    borderColor: '#31425F',
    color: '#FFF',
    borderRadius: 14,
    padding: 14,
    marginTop: 10,
    fontSize: 16,
  },
  textarea: { minHeight: 100, textAlignVertical: 'top' },
  chipsWrap: { flexDirection: 'row-reverse', flexWrap: 'wrap', gap: 9 },
  chip: {
    paddingVertical: 10,
    paddingHorizontal: 13,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: '#31425F',
    backgroundColor: '#0D1424',
  },
  chipActive: { backgroundColor: '#F6C343', borderColor: '#F6C343' },
  chipText: { color: '#FFF', fontWeight: '800' },
  chipTextActive: { color: '#111827' },
  estimateBox: {
    backgroundColor: '#0D1424',
    borderRadius: 18,
    padding: 16,
    marginTop: 18,
    borderWidth: 1,
    borderColor: '#31425F',
  },
  estimateLabel: { color: '#A8B3C7', textAlign: 'right' },
  estimateValue: { color: '#F6C343', fontSize: 34, fontWeight: '900', textAlign: 'right', marginVertical: 6 },
  featureRow: { flexDirection: 'row-reverse', alignItems: 'center', gap: 8, marginBottom: 10 },
  featureText: { color: '#B8C2D6', flex: 1, textAlign: 'right', lineHeight: 22 },
  brandImage: { width: '100%', height: 410, borderRadius: 18, marginBottom: 14, backgroundColor: '#0D1424' },
  navGrid: { flexDirection: 'row-reverse', gap: 10, marginBottom: 14 },
  navItem: {
    flex: 1,
    backgroundColor: '#0D1424',
    borderRadius: 16,
    paddingVertical: 14,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#26364F',
  },
  navText: { color: '#FFF', fontSize: 12, marginTop: 5, fontWeight: '800' },
  savedItem: { backgroundColor: '#0D1424', borderRadius: 14, padding: 13, marginTop: 10 },
  savedTitle: { color: '#F6C343', fontWeight: '900', textAlign: 'right', marginBottom: 4 },
});
